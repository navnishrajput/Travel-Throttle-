package com.travelthrottle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelThrottleApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelThrottleApiApplication.class, args);
	}

}
